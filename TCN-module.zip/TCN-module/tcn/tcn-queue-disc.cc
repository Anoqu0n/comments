#include "ns3/log.h"
#include "ns3/enum.h"
#include "ns3/uinteger.h"
#include "ns3/double.h"
#include "ns3/simulator.h"
#include "ns3/abort.h"
#include "tcn-queue-disc.h"
#include "ns3/drop-tail-queue.h"
#include "tcn-tag.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("TcnQueueDisc");

NS_OBJECT_ENSURE_REGISTERED (TcnQueueDisc);

TypeId TcnQueueDisc::GetTypeId (void)
{
    static TypeId tid = TypeId ("ns3::TcnQueueDisc")
        .SetParent<QueueDisc> ()
        .SetGroupName("TrafficControl")
        .AddConstructor<TcnQueueDisc> ()
        .AddAttribute ("MeanPktSize",
                                     "Average of packet size",
                                     UintegerValue (500),
                                     MakeUintegerAccessor (&TcnQueueDisc::m_meanPktSize),
                                     MakeUintegerChecker<uint32_t> ())
        .AddAttribute ("IdlePktSize",
                                     "Average packet size used during idle times. Used when m_cautions = 3",
                                     UintegerValue (0),
                                     MakeUintegerAccessor (&TcnQueueDisc::m_idlePktSize),
                                     MakeUintegerChecker<uint32_t> ())
        .AddAttribute ("MinTh",
                                     "Minimum sojourn time threshold in MicroSeconds",
                                     TimeValue (MicroSeconds(20.0)),
                                     MakeTimeAccessor (&TcnQueueDisc::m_minTh),
                                     MakeTimeChecker ())
        .AddAttribute ("MaxTh",
                                     "Maximum average length threshold in packets/bytes",
                                     TimeValue (MicroSeconds(40.0)),
                                     MakeTimeAccessor (&TcnQueueDisc::m_maxTh),
                                     MakeTimeChecker ())
        .AddAttribute ("MaxSize",
                                     "The maximum number of packets accepted by this queue disc",
                                     QueueSizeValue (QueueSize ("25p")),
                                     MakeQueueSizeAccessor (&QueueDisc::SetMaxSize,
                                                                                    &QueueDisc::GetMaxSize),
                                     MakeQueueSizeChecker ())
        .AddAttribute ("QW",
                                     "Queue weight related to the exponential weighted moving average (EWMA)",
                                     DoubleValue (0.002),
                                     MakeDoubleAccessor (&TcnQueueDisc::m_qW),
                                     MakeDoubleChecker <double> ())
        .AddAttribute ("LInterm",
                                     "The maximum probability of marking a packet",
                                     DoubleValue (50),
                                     MakeDoubleAccessor (&TcnQueueDisc::m_lInterm),
                                     MakeDoubleChecker <double> ())
        .AddAttribute ("Ns1Compat",
                                     "NS-1 compatibility",
                                     BooleanValue (false),
                                     MakeBooleanAccessor (&TcnQueueDisc::m_isNs1Compat),
                                     MakeBooleanChecker ())
        .AddAttribute ("LinkBandwidth", 
                                     "The RED link bandwidth",
                                     DataRateValue (DataRate ("1.5Mbps")),
                                     MakeDataRateAccessor (&TcnQueueDisc::m_linkBandwidth),
                                     MakeDataRateChecker ())
        .AddAttribute ("LinkDelay", 
                                     "The RED link delay",
                                     TimeValue (MilliSeconds (20)),
                                     MakeTimeAccessor (&TcnQueueDisc::m_linkDelay),
                                     MakeTimeChecker ())
        .AddAttribute ("UseEcn",
                                     "True to use ECN (packets are marked instead of being dropped)",
                                     BooleanValue (true),
                                     MakeBooleanAccessor (&TcnQueueDisc::m_useEcn),
                                     MakeBooleanChecker ())
    ;

    return tid;
}

TcnQueueDisc::TcnQueueDisc () :
    QueueDisc (QueueDiscSizePolicy::SINGLE_INTERNAL_QUEUE)
{
    NS_LOG_FUNCTION (this);
    m_uv = CreateObject<UniformRandomVariable> ();
}

TcnQueueDisc::~TcnQueueDisc ()
{
    NS_LOG_FUNCTION (this);
}

void
TcnQueueDisc::DoDispose (void)
{
    NS_LOG_FUNCTION (this);
    m_uv = 0;
    QueueDisc::DoDispose ();
}



void
TcnQueueDisc::SetTh (Time minTh, Time maxTh)
{
    NS_LOG_FUNCTION (this << minTh << maxTh);
    NS_ASSERT (minTh <= maxTh);
    m_minTh = minTh;
    m_maxTh = maxTh;
}


int64_t 
TcnQueueDisc::AssignStreams (int64_t stream)
{
    NS_LOG_FUNCTION (this << stream);
    m_uv->SetStream (stream);
    return 1;
}


bool
TcnQueueDisc::DoEnqueue (Ptr<QueueDiscItem> item)
{
    NS_LOG_FUNCTION (this << item);

    NS_LOG_DEBUG ("\t bytesInQueue  " << GetInternalQueue (0)->GetNBytes () << "\tQavg " << m_qAvg);
    NS_LOG_DEBUG ("\t packetsInQueue  " << GetInternalQueue (0)->GetNPackets () << "\tQavg " << m_qAvg);

    m_count++;
    m_countBytes += item->GetSize ();

    // Record injection timestamp
    /* 补全代码 */
    TcnTag tcn_intime;
    tcn_intime.SetDeadline( ？ );         // 补全问号处代码
    item ->GetPacket()->AddPacketTag(tcn_intime);

    bool retval = GetInternalQueue (0)->Enqueue (item);

    // If Queue::Enqueue fails, QueueDisc::DropBeforeEnqueue is called by the
    // internal queue because QueueDisc::AddInternalQueue sets the trace callback

    NS_LOG_LOGIC ("Number packets " << GetInternalQueue (0)->GetNPackets ());
    NS_LOG_LOGIC ("Number bytes " << GetInternalQueue (0)->GetNBytes ());

    return retval;
}


/*
 * Note: if the link bandwidth changes in the course of the
 * simulation, the bandwidth-dependent TCN parameters do not change.
 * This should be fixed, but it would require some extra parameters,
 * and didn't seem worth the trouble...
 */
void
TcnQueueDisc::InitializeParams (void)
{
    NS_LOG_FUNCTION (this);
    NS_LOG_INFO ("Initializing TCN params.");

    m_cautious = 0;
    m_ptc = m_linkBandwidth.GetBitRate () / (8.0 * m_meanPktSize);

    if ( m_minTh == MicroSeconds(0) && m_maxTh == MicroSeconds(0) )
        {
            m_minTh = MicroSeconds(20.0); //us

            // set m_maxTh to two times
            m_maxTh = 2 * m_minTh;
        }

    NS_ASSERT (m_minTh <= m_maxTh);

    m_qAvg = 0.0;
    m_count = 0;
    m_countBytes = 0;
    m_old = 0;
    m_idle = 1;
    m_curMaxP = 1.0 / m_lInterm;
    m_idleTime = NanoSeconds (0);

/*
 * If m_qW=0, set it to a reasonable value of 1-exp(-1/C)
 * This corresponds to choosing m_qW to be of that value for
 * which the packet time constant -1/ln(1-m)qW) per default RTT 
 * of 100ms is an order of magnitude more than the link capacity, C.
 *
 * If m_qW=-1, then the queue weight is set to be a function of
 * the bandwidth and the link propagation delay.  In particular, 
 * the default RTT is assumed to be three times the link delay and 
 * transmission delay, if this gives a default RTT greater than 100 ms. 
 *
 * If m_qW=-2, set it to a reasonable value of 1-exp(-10/C).
 */
    if (m_qW == 0.0)
        {
            m_qW = 1.0 - std::exp (-1.0 / m_ptc);
        }
    else if (m_qW == -1.0)
        {
            double rtt = 3.0 * (m_linkDelay.GetSeconds () + 1.0 / m_ptc);

            if (rtt < 0.1)
                {
                    rtt = 0.1;
                }
            m_qW = 1.0 - std::exp (-1.0 / (10 * rtt * m_ptc));
        }
    else if (m_qW == -2.0)
        {
            m_qW = 1.0 - std::exp (-10.0 / m_ptc);
        }
}



// Compute the average queue size
double
TcnQueueDisc::Estimator (uint32_t nQueued, uint32_t m, double qAvg, double qW)
{
    NS_LOG_FUNCTION (this << nQueued << m << qAvg << qW);

    double newAve = qAvg * std::pow (1.0 - qW, m);
    newAve += qW * nQueued;

    Time now = Simulator::Now ();

    return newAve;
}


// Check if packet p needs to be marked due to probability mark
uint32_t
TcnQueueDisc::MarkEarly (Ptr<QueueDiscItem> item, uint32_t qSize)
{
    NS_LOG_FUNCTION (this << item << qSize);

    double prob1 = CalculatePNew ();
    m_vProb = ModifyP (prob1, item->GetSize ());

    // Mark probability is computed, pick random number and act
    if (m_cautious == 1)
        {
            /*
             * Don't mark if the instantaneous queue is much below the average.
             * For experimental purposes only.
             * pkts: the number of packets arriving in 50 ms
             */
            double pkts = m_ptc * 0.05;
            double fraction = std::pow ((1 - m_qW), pkts);

            if ((double) qSize < fraction * m_qAvg)
                {
                    // Queue could have been empty for 0.05 seconds
                    return 0;
                }
        }

    double u = m_uv->GetValue ();

    if (m_cautious == 2)
        {
            /*
             * Decrease the drop probability if the instantaneous
             * queue is much below the average.
             * For experimental purposes only.
             * pkts: the number of packets arriving in 50 ms
             */
            double pkts = m_ptc * 0.05;
            double fraction = std::pow ((1 - m_qW), pkts);
            double ratio = qSize / (fraction * m_qAvg);

            if (ratio < 1.0)
                {
                    u *= 1.0 / ratio;
                }
        }

    if (u <= m_vProb)
        {
            NS_LOG_LOGIC ("u <= m_vProb; u " << u << "; m_vProb " << m_vProb);

            m_count = 0;
            m_countBytes = 0;
            /// \todo Implement set bit to mark

            return 1; // mark
        }

    return 0; // no mark
}



// Returns a probability using these function parameters for the DropEarly function
double
TcnQueueDisc::CalculatePNew (void)
{
    NS_LOG_FUNCTION (this);
    double p = 1;

    if (m_pSojotime >= m_maxTh)
        {
            /* 
             * OLD: p continues to range linearly above m_curMaxP as
             * the average queue size ranges above m_maxTh.
             * NEW: p is set to 1.0
             */
            p = 1.0;
        }
    else
        {
            /*
             * p ranges from 0 to m_curMaxP as the average queue size ranges from
             * m_minTh to m_maxTh
             */
            //p = m_vA * m_qAvg + m_vB;

            p *= m_curMaxP;
        }

    if (p > 1.0)
        {
            p = 1.0;
        }

    return p;
}

// Returns a probability using these function parameters for the DropEarly function
double 
TcnQueueDisc::ModifyP (double p, uint32_t size)
{
    NS_LOG_FUNCTION (this << p << size);
    double count1 = (double) m_count;

    if (GetMaxSize ().GetUnit () == QueueSizeUnit::BYTES)
        {
            count1 = (double) (m_countBytes / m_meanPktSize);
        }

    if (count1 * p < 1.0)
        {
            p /= (1.0 - count1 * p);
        }
    else
        {
            p = 1.0;
        }
        //}

    if ((GetMaxSize ().GetUnit () == QueueSizeUnit::BYTES) && (p < 1.0))
        {
            p = (p * size) / m_meanPktSize;
        }

    if (p > 1.0)
        {
            p = 1.0;
        }

    return p;
}



Ptr<QueueDiscItem>
TcnQueueDisc::DoDequeue (void)
{
    NS_LOG_FUNCTION (this);

    if (GetInternalQueue (0)->IsEmpty ())
        {
            NS_LOG_LOGIC ("Queue empty");
            m_idle = 1;
            m_idleTime = Simulator::Now ();

            return 0;
        }
    else
        {
            m_idle = 0;

            Ptr<QueueDiscItem> item = GetInternalQueue (0)->Dequeue ();
            NS_LOG_LOGIC ("Popped " << item);

            // get sojourn time of current packets
            // get enqueue time;
            TcnTag tcn_intime; 
            item ->GetPacket()->RemovePacketTag(tcn_intime);
            Time intime = tcn_intime.GetDeadline();

            // calculate sojourn time
            /*======= 补全代码 ========*/
            m_pSojotime = ？;    // 补全问号处代码

            // get current queue size
            uint32_t nQueued = GetInternalQueue (0)->GetCurrentSize ().GetValue ();

            uint32_t markType = DTYPE_NONE;
            if (m_pSojotime >= ？ && nQueued > 1)   // 补全问号处代码
                {
                    if ((m_pSojotime >= ？))  // 补全问号处代码
                        {
                            NS_LOG_DEBUG ("adding FORCED MARK");
                            markType = DTYPE_FORCED;
                        }
                    else if (m_old == 0)
                        {
                            /* 
                             * The average queue size has just crossed the
                             * threshold from below to above m_minTh, or
                             * from above m_minTh with an empty queue to
                             * above m_minTh with a nonempty queue.
                             */
                            m_count = 1;
                            m_countBytes = item->GetSize ();
                            m_old = 1;
                        }
                    else if (MarkEarly (item, nQueued))
                        {
                            NS_LOG_LOGIC ("MarkEarly returns 1");
                            markType = DTYPE_UNFORCED;
                        }
                }
            else 
                {
                    // No packets are being marked
                    m_vProb = 0.0;
                    m_old = 0;
                }

            if (markType == DTYPE_UNFORCED)
                {
                    NS_LOG_DEBUG ("\t Marking due to Prob Mark " << m_qAvg);
                    //std::cout << "\t Marking due to Prob Mark " << std::endl;
                    if(!Mark (item, UNFORCED_MARK))
                    {
                        std::cout << " Please enable ECN setting of TCP!" << std::endl;
                    }
                }
            else if (markType == DTYPE_FORCED)
                {
                    //Mark (item, FORCED_MARK);
                    if(!Mark (item, FORCED_MARK))
                    {
                        std::cout << " Please enable ECN setting of TCP!" << std::endl;
                    }
                    //std::cout << "\t Marking due to Hard Mark " << std::endl;
                    NS_LOG_DEBUG ("\t Marking due to Hard Mark " << m_qAvg);
                }

            NS_LOG_LOGIC ("Number packets " << GetInternalQueue (0)->GetNPackets ());
            NS_LOG_LOGIC ("Number bytes " << GetInternalQueue (0)->GetNBytes ());

            return item;
        }
}

Ptr<const QueueDiscItem>
TcnQueueDisc::DoPeek (void)
{
    NS_LOG_FUNCTION (this);
    if (GetInternalQueue (0)->IsEmpty ())
        {
            NS_LOG_LOGIC ("Queue empty");
            return 0;
        }

    Ptr<const QueueDiscItem> item = GetInternalQueue (0)->Peek ();

    NS_LOG_LOGIC ("Number packets " << GetInternalQueue (0)->GetNPackets ());
    NS_LOG_LOGIC ("Number bytes " << GetInternalQueue (0)->GetNBytes ());

    return item;
}


bool
TcnQueueDisc::CheckConfig (void)
{
    NS_LOG_FUNCTION (this);
    if (GetNQueueDiscClasses () > 0)
        {
            NS_LOG_ERROR ("TcnQueueDisc cannot have classes");
            return false;
        }

    if (GetNPacketFilters () > 0)
        {
            NS_LOG_ERROR ("TcnQueueDisc cannot have packet filters");
            return false;
        }

    if (GetNInternalQueues () == 0)
        {
            // add a DropTail queue
            AddInternalQueue (CreateObjectWithAttributes<DropTailQueue<QueueDiscItem> >
                                                    ("MaxSize", QueueSizeValue (GetMaxSize ())));
        }

    if (GetNInternalQueues () != 1)
        {
            NS_LOG_ERROR ("TcnQueueDisc needs 1 internal queue");
            return false;
        }

    return true;
}

} // namespace ns3



// bool
// TcnQueueDisc::DoEnqueue (Ptr<QueueDiscItem> item)
// {
//     NS_LOG_FUNCTION (this << item);

//     // get current queue size
//     uint32_t nQueued = GetInternalQueue (0)->GetCurrentSize ().GetValue ();

//     // simulate number of packets arrival during idle period
//     uint32_t m = 0;

//     if (m_idle == 1)
//         {
//             NS_LOG_DEBUG ("RED Queue Disc is idle.");
//             Time now = Simulator::Now ();

//             if (m_cautious == 3)
//                 {
//                     double ptc = m_ptc * m_meanPktSize / m_idlePktSize;
//                     m = uint32_t (ptc * (now - m_idleTime).GetSeconds ());
//                 }
//             else
//                 {
//                     m = uint32_t (m_ptc * (now - m_idleTime).GetSeconds ());
//                 }

//             m_idle = 0;
//         }

//     //  Recalculate average package length   
//     m_qAvg = Estimator (nQueued, m + 1, m_qAvg, m_qW);

//     NS_LOG_DEBUG ("\t bytesInQueue  " << GetInternalQueue (0)->GetNBytes () << "\tQavg " << m_qAvg);
//     NS_LOG_DEBUG ("\t packetsInQueue  " << GetInternalQueue (0)->GetNPackets () << "\tQavg " << m_qAvg);

//     m_count++;
//     m_countBytes += item->GetSize ();

//     uint32_t dropType = DTYPE_NONE;
//     if (m_qAvg >= m_minTh && nQueued > 1)
//         {
//             if ((!m_isGentle && m_qAvg >= m_maxTh) ||
//                     (m_isGentle && m_qAvg >= 2 * m_maxTh))
//                 {
//                     NS_LOG_DEBUG ("adding DROP FORCED MARK");
//                     dropType = DTYPE_FORCED;
//                 }
//             else if (m_old == 0)
//                 {
                     
//                      * The average queue size has just crossed the
//                      * threshold from below to above m_minTh, or
//                      * from above m_minTh with an empty queue to
//                      * above m_minTh with a nonempty queue.
                     
//                     m_count = 1;
//                     m_countBytes = item->GetSize ();
//                     m_old = 1;
//                 }
//             else if (DropEarly (item, nQueued))
//                 {
//                     NS_LOG_LOGIC ("DropEarly returns 1");
//                     dropType = DTYPE_UNFORCED;
//                 }
//         }
//     else 
//         {
//             // No packets are being dropped
//             m_vProb = 0.0;
//             m_old = 0;
//         }

//     if (dropType == DTYPE_UNFORCED)
//         {
//             if (!m_useEcn || !Mark (item, UNFORCED_MARK))
//                 {
//                     NS_LOG_DEBUG ("\t Dropping due to Prob Mark " << m_qAvg);
//                     DropBeforeEnqueue (item, UNFORCED_DROP);
//                     return false;
//                 }
//             NS_LOG_DEBUG ("\t Marking due to Prob Mark " << m_qAvg);
//         }
//     else if (dropType == DTYPE_FORCED)
//         {
//             if (m_useHardDrop || !m_useEcn || !Mark (item, FORCED_MARK))
//                 {
//                     NS_LOG_DEBUG ("\t Dropping due to Hard Mark " << m_qAvg);
//                     DropBeforeEnqueue (item, FORCED_DROP);
//                     if (m_isNs1Compat)
//                         {
//                             m_count = 0;
//                             m_countBytes = 0;
//                         }
//                     return false;
//                 }
//             NS_LOG_DEBUG ("\t Marking due to Hard Mark " << m_qAvg);
//         }

//     bool retval = GetInternalQueue (0)->Enqueue (item);

//     // If Queue::Enqueue fails, QueueDisc::DropBeforeEnqueue is called by the
//     // internal queue because QueueDisc::AddInternalQueue sets the trace callback

//     NS_LOG_LOGIC ("Number packets " << GetInternalQueue (0)->GetNPackets ());
//     NS_LOG_LOGIC ("Number bytes " << GetInternalQueue (0)->GetNBytes ());

//     return retval;
// }