#ifndef TCN_QUEUE_DISC_H
#define TCN_QUEUE_DISC_H

#include "ns3/queue-disc.h"
#include "ns3/nstime.h"
#include "ns3/boolean.h"
#include "ns3/data-rate.h"
#include "ns3/random-variable-stream.h"

namespace ns3 {

class TraceContainer;

/**
 * \ingroup traffic-control
 *
 * \brief A TCN packet queue disc
 */
class TcnQueueDisc : public QueueDisc
{
public:
  /**
   * \brief Get the type ID.
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);
  /**
   * \brief TcnQueueDisc Constructor
   *
   * Create a TCN queue disc
   */
  TcnQueueDisc ();

  /**
   * \brief Destructor
   *
   * Destructor
   */ 
  virtual ~TcnQueueDisc ();

  /** 
   * \brief Mark types
   */
  enum
  {
    DTYPE_NONE,        //!< Ok, no mark
    DTYPE_FORCED,      //!< A "forced" mark
    DTYPE_UNFORCED,    //!< An "unforced" (random) mark
  };


  /**
   * \brief Set the thresh limits of TCN.
   *
   * \param minTh Minimum thresh in sojourn time.
   * \param maxTh Maximum thresh in sojourn time.
   */
  void SetTh (Time minTh, Time maxTh);

 /**
  * Assign a fixed random variable stream number to the random variables
  * used by this model.  Return the number of streams (possibly zero) that
  * have been assigned.
  *
  * \param stream first stream index to use
  * \return the number of stream indices assigned by this model
  */
  int64_t AssignStreams (int64_t stream);

  // Reasons for dropping packets
  //static constexpr const char* UNFORCED_DROP = "Unforced drop";  //!< Early probability drops
  //static constexpr const char* FORCED_DROP = "Forced drop";      //!< Forced drops, m_qAvg > m_maxTh
  // Reasons for marking packets
  static constexpr const char* UNFORCED_MARK = "Unforced mark";  //!< Early probability marks
  static constexpr const char* FORCED_MARK = "Forced mark";      //!< Forced marks, m_qAvg > m_maxTh

protected:
  /**
   * \brief Dispose of the object
   */
  virtual void DoDispose (void);

private:
  virtual bool DoEnqueue (Ptr<QueueDiscItem> item);
  virtual Ptr<QueueDiscItem> DoDequeue (void);
  virtual Ptr<const QueueDiscItem> DoPeek (void);
  virtual bool CheckConfig (void);

  /**
   * \brief Initialize the queue parameters.
   *
   * Note: if the link bandwidth changes in the course of the
   * simulation, the bandwidth-dependent TCN parameters do not change.
   * This should be fixed, but it would require some extra parameters,
   * and didn't seem worth the trouble...
   */
  virtual void InitializeParams (void);
  /**
   * \brief Compute the average queue size
   * \param nQueued number of queued packets
   * \param m simulated number of packets arrival during idle period
   * \param qAvg average queue size
   * \param qW queue weight given to cur q size sample
   * \returns new average queue size
   */
  double Estimator (uint32_t nQueued, uint32_t m, double qAvg, double qW);

  /**
   * \brief Check if a packet needs to be marked due to probability mark
   * \param item queue item
   * \param qSize queue size
   * \returns 0 for no mark, 1 for mark
   */
  uint32_t MarkEarly (Ptr<QueueDiscItem> item, uint32_t qSize);


  /**
   * \brief Returns a probability using these function parameters for the MarkEarly function
   * \returns Prob. of packet mark before "count"
   */
  double CalculatePNew (void);

  /**
   * \brief Returns a probability using these function parameters for the MarkEarly function
   * \param p Prob. of packet mark before "count"
   * \param size packet size
   * \returns Prob. of packet mark
   */
  double ModifyP (double p, uint32_t size);

  // ** Variables supplied by user
  uint32_t m_meanPktSize;   //!< Avg pkt size
  uint32_t m_idlePktSize;   //!< Avg pkt size used during idle times

  bool m_isWait;            //!< True for waiting between dropped packets
  bool m_isGentle;          //!< True to increase dropping prob. slowly when m_qAvg exceeds m_maxTh

  Time m_minTh;           //!< Minimum threshold for sojourn time (us)
  Time m_maxTh;           //!< Maximum threshold for sojourn time (us)

  double m_qW;              //!< Queue weight given to cur queue size sample
  double m_lInterm;         //!< The max probability of dropping a packet
  bool m_isNs1Compat;       //!< Ns-1 compatibility

  DataRate m_linkBandwidth; //!< Link bandwidth
  Time m_linkDelay;         //!< Link delay

  bool m_useEcn;            //!< True if ECN is used (packets are marked instead of being dropped)

  // ** Variables maintained by RED
  double m_vA;              //!< 1.0 / (m_maxTh - m_minTh)
  double m_vB;              //!< -m_minTh / (m_maxTh - m_minTh)
  double m_vC;              //!< (1.0 - m_curMaxP) / m_maxTh - used in "gentle" mode
  double m_vD;              //!< 2.0 * m_curMaxP - 1.0 - used in "gentle" mode
  double m_curMaxP;         //!< Current max_p
  //Time m_lastSet;           //!< Last time m_curMaxP was updated
  double m_vProb;           //!< Prob. of packet mark
  uint32_t m_countBytes;    //!< Number of bytes since last mark
  uint32_t m_old;           //!< 0 when average queue first exceeds threshold
  uint32_t m_idle;          //!< 0/1 idle status
  double m_ptc;             //!< packet time constant in packets/second
  Time m_pSojotime;         //!< packet sojourn time
  double m_qAvg;            //!< Average queue length
  uint32_t m_count;         //!< Number of packets since last random number generation

  /**
   * 0 for default RED
   * 1 experimental (see red-queue-disc.cc)
   * 2 experimental (see red-queue-disc.cc)
   * 3 use Idle packet size in the ptc
   */
  uint32_t m_cautious;
  Time m_idleTime;          //!< Start of current idle period

  Ptr<UniformRandomVariable> m_uv;  //!< rng stream
};

}; // namespace ns3

#endif // RED_QUEUE_DISC_H
